import os

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'your_generated_secret_key'  
    SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://reseller_phython:n;fi8Myd!mE&@localhost/reseller_phython'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
