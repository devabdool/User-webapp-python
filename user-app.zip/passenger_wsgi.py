import sys
import os

sys.path.insert(0, '/home/reseller/kambamfb.com.ng/esdiac/site-packages')

from flask import Flask  
from app import app as application  
